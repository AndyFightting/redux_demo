import React,{ Component } from 'react';
import { createStore,combineReducers } from 'redux'

// 生成新对象
 // Object.assign({}, state, { action });
 //  { ...state, ...action };

const defaultState = {
    num : 0,
    msg : '',
};

function numReducer(state = defaultState, action) {
    switch (action.type) {
        case 'ADD':
            return{
                num : state.num + action.num,
                msg : action.msg,
            };

        case 'DEL':
            return{
                num : state.num - action.num,
                msg : action.msg,
            };

        default:
            return state
    }
}

// 集合多个reducer用于初始化store,这里只有一个numReducer
const rootReducer = combineReducers({
    numReducer, //相当于一个同名的 key：value, 通过 store.getState().numReducer 获取对应的state
});

let store = createStore(rootReducer);
var unsubscribe;

export default class MyView extends Component{

      constructor(props) {
        super(props);
        this.state = {
            dic: store.getState().numReducer,//获取numReducer对应的state
        };
      }

    componentWillMount() {
        //注册监听
        unsubscribe =  store.subscribe(this.numChanged.bind(this));
    }

    componentWillUnMount() {
        //取消监听
        unsubscribe();
    }

    numChanged(){
          this.setState({
              dic: store.getState().numReducer,//获取numReducer对应的state
          });
      }

      render(){
          return(
              <div>
                  {this.state.dic.num} ----   {this.state.dic.msg}
                  <button onClick={this.addTaped.bind(this)} >每次加3</button>
                  <button onClick={this.delTaped.bind(this)} >每次减2</button>
              </div>
          );
      }

    addTaped(){
        store.dispatch(addAction(3))
      }

    delTaped(){
        store.dispatch(delAction(2))
    }
}

function addAction(num) {
    return {
        type: 'ADD',
        num: num,
        msg: 'add',
    }
}

function delAction(num) {
    return {
        type: 'DEL',
        num: num,
        msg: 'del',
    }
}
